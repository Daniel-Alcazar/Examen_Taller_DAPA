export class ExamenDto {
    readonly description: string;
    readonly isDone: boolean;
}