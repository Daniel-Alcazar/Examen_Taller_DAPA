import { Controller, Get, Render } from '@nestjs/common';
import { METHODS } from 'http';
import { Request } from '@nestjs/common';



@Controller('nada/v1')
export class ExamenController {
    @Get()
    @Render('public') 
    root() {
        return { message: 'hola hola!' };
    }
}   