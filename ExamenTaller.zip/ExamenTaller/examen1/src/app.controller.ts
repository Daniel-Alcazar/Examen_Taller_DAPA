import { Get, Controller, Render } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('/')
export class AppController {
  constructor(private appService: AppService) {}

  @Get('/')
  @Render('raiz') 
  hello() {
    return { message: '¡Hola a todos!' };
  }

  @Get('/exam/dapa')
  @Render('index')
  root() {
    return { message: 'examen' };
  }

}